'use strict';

module.exports = [
    {
        name: 'easeOutBounce',
        leaveTiming: 0.3,
        leaveEase: 'linear'
    },
    {
        name: 'easeOutExpo'
    }
]