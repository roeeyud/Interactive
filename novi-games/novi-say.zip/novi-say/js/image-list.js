module.exports = [
    'files/images/kiss-lady.png',
    'files/images/flam.png',
    'files/images/wig.png',
    'files/images/prog_1.png',
    'files/images/prog_2.png',
    'files/images/prog_3.png',
    'files/images/camera.png'
]